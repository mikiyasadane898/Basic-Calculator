function appendToDisplay(value) {
    document.getElementById("in").value += value;
}

function clearDisplay() {
    document.getElementById("in").value = "";
}

function backspace() {
    const display = document.getElementById("in");
    display.value = display.value.slice(0, -1);
}

function calculateResult() {
    const display = document.getElementById("in");
    const expression = display.value;

    try {
        const result = evaluateExpression(expression);
        display.value = roundResult(result);
    } catch (error) {
        display.value = "Error";
    }
}

function calculateSquare() {
    const display = document.getElementById("in");
    const currentValue = display.value;

    if (!isNaN(currentValue)) {
        display.value = roundResult(Math.pow(parseFloat(currentValue), 2));
    } else {
        display.value = "Error";
    }
}

function evaluateExpression(expression) {
    const postfix = infixToPostfix(expression);
    return evaluatePostfix(postfix);
}

function infixToPostfix(infix) {
    const output = [];
    const operators = [];
    const precedence = {
        "+": 1,
        "-": 1,
        "*": 2,
        "/": 2,
        "%": 2,
        "sin(": 3,
        "cos(": 3,
        "tan(": 3,
        "√(": 3
    };

    const tokens = tokenize(infix);

    for (let i = 0; i < tokens.length; i++) {
        const token = tokens[i];

        if (!isNaN(token)) {
            output.push(parseFloat(token));
        } else if (token in precedence) {
            while (
                operators.length &&
                precedence[operators[operators.length - 1]] >= precedence[token]
            ) {
                output.push(operators.pop());
            }
            operators.push(token);
        } else if (token === "(") {
            operators.push(token);
        } else if (token === ")") {
            while (operators.length && operators[operators.length - 1] !== "(") {
                output.push(operators.pop());
            }
            operators.pop();
        }
    }

    while (operators.length) {
        output.push(operators.pop());
    }

    return output;
}

function evaluatePostfix(postfix) {
    const stack = [];

    for (const token of postfix) {
        if (typeof token === "number") {
            stack.push(token);
        } else {
            let result;
            if (["sin(", "cos(", "tan(", "√("].includes(token)) {
                const a = stack.pop();
                switch (token) {
                    case "sin(":
                        result = Math.sin(a * (Math.PI / 180)); 
                        break;
                    case "cos(":
                        result = Math.cos(a * (Math.PI / 180));
                        break;
                    case "tan(":
                        result = Math.tan(a * (Math.PI / 180)); 
                        break;
                    case "√(":
                        result = Math.sqrt(a);
                        break;
                    default:
                        throw new Error("Unknown operator: " + token);
                }
            } else {
                const b = stack.pop();
                const a = stack.length === 0 ? 0 : stack.pop(); 

                switch (token) {
                    case "+":
                        result = a + b;
                        break;
                    case "-":
                        result = a - b;
                        break;
                    case "*":
                        result = a * b;
                        break;
                    case "/":
                        result = a / b;
                        break;
                    case "%":
                        result = a % b;
                        break;
                    default:
                        throw new Error("Unknown operator: " + token);
                }
            }
            stack.push(result);
        }
    }

    return stack[0];
}

function roundResult(value, decimals = 5) {
    const factor = Math.pow(10, decimals);
    return Math.round(value * factor) / factor;
}

function tokenize(expression) {
    const regex = /(\d+\.?\d*|[-+*/%()]|sin\(|cos\(|tan\(|√\()/g;
    return expression.match(regex);
}

function changeWidth() {
    const container = document.getElementById("container");
    const width = container.offsetWidth;
    if (width < 400) {
        document.getElementById("container").style.width = "400px";
        document.getElementById("in").style.width = "280px";

        const elements = document.getElementsByClassName("scientific");
        for (let i = 0; i < elements.length; i++) {
            elements[i].style.display = "inline";
        }
    } else {
        document.getElementById("container").style.width = "300px";
        document.getElementById("in").style.width = "200px";
        const elements = document.getElementsByClassName("scientific");
        for (let i = 0; i < elements.length; i++) {
            elements[i].style.display = "none";
        }
    }
}
